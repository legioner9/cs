# SolidDNA Custom Properties
This project shows how to read/edit custom propeties using SolidDNA and a WPF Add-in

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube


