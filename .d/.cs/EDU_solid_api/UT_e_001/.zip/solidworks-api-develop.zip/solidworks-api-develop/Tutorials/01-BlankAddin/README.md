# Creating a Blank Add-in
This project creates a blank add-in that you can register as an add-in to SolidWorks using regasm or the Add-in Installer in this repository

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube


