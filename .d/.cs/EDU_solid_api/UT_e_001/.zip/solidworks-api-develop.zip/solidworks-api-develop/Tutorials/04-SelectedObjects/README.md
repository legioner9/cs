# SolidDNA Custom Properties
This project shows how to read/edit custom propeties using SolidDNA and a WPF Add-in

NOTE: This is a slightly enhanced version on the standard tutorial, with the addition
of a simpler custom property getter, and the Length value being gettable from a
selected dimension

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube


