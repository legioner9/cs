﻿using System.Windows.Controls;

namespace SolidDna.WpfAddIn
{
    /// <summary>
    /// Interaction logic for MyAddinControl.xaml
    /// </summary>
    public partial class MyAddinControl : UserControl
    {
        public MyAddinControl()
        {
            InitializeComponent();
        }
    }
}
