# SolidDNA Creating a WPF Taskpane
This project creates a SolidWorks AddIn using the new SolidDNA SDK, adding a basic WPF control as the main UI 

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube


