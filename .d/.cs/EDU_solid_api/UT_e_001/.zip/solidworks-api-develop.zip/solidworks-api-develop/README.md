# SolidWorks API
This will be the main repository for all of my C# work with SolidWorks API

# Gettings Started
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

https://www.youtube.com/c/angelsix

https://www.youtube.com/playlist?list=PLrW43fNmjaQVMN1-lsB29ECnHRlA4ebYn
