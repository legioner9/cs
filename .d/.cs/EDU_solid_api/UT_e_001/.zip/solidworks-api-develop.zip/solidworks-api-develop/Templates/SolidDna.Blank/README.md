# SolidDNA using NuGet Package
This project shows how to create a basic SolidDNA project using the new NuGet package instead of referencing source code directly

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube


