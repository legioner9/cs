# SolidDNA Stand Alone Application
This project shows how easy it is to use SolidDNA from a stand alone application not integrated into SolidWorks. This allows you to quickly run and test code while keeping SolidWorks running.

Start up SolidWorks, then run this project. It will connect to the active SolidWorks instance and then you have access to all of the SolidDNA API.

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube


