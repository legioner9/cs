﻿using System;
using static AngelSix.SolidDna.SolidWorksEnvironment;

public class SolidDnaScript
{
    public void Run()
    {
        //CODE
    }
}
