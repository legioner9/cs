# SolidWorks Add-in Installer
A tool to aid in running the correct RegAsm command on a SolidWorks Add-in Dll to visually install and uninstall add-ins

NOTE: This application is designed to run on x64 machines and x64 installs of SolidWorks by default

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube

