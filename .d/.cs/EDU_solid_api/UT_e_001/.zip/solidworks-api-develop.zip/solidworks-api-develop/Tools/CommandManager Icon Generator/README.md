# SolidWorks Command Manager Icon Generator
When creating SolidWorks Command Manager tabs and buttons etc... you must provide a bunch of image files in various sizes
that contain all images for all buttons you want to use in a particular group.

That task is painstaking doing it manually, so this tool can simply accept a list of images and it will combine
the images into the icon list files of all possible sizes

Simply drop your images onto the exe to generate the icon lists. Alternatively open the exe and specify each image by typing the relative or full path

# Video
I will be making videos available on my YouTube channel that will be guides to everything contained in this repository

http://www.angelsix.com/youtube

