﻿namespace XCad.Examples.FurnitureConfigurator.Enums
{
    public enum OrderItemStatus_e
    {
        Available,
        Custom,
        OutOfStock
    }
}
