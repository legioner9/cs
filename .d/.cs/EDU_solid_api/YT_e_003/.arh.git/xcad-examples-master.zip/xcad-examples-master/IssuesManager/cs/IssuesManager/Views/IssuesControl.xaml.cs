﻿using System.Windows.Controls;

namespace XCad.Examples.IssuesManager.Views
{
    public partial class IssuesControl : UserControl
    {
        public IssuesControl()
        {
            InitializeComponent();
        }
    }
}
