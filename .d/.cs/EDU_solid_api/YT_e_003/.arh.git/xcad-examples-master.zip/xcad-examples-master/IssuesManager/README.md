![Issues Manager in TaskPane](issues-taskpane.png)

This example demonstrates how to add WPF control into the SOLIDWORKS Task Pane and manage issues for file.

It allows to create and delete issues and specify title, description, severity and status.

Information about issue stored directly in the file stream and can be retrieved once file is reopened.