![Toggle buttons](toggle-bitmap-buttons.gif)

This example demonstrates how to create toggle bitmap button (one checked at a time) in SOLIDWORKS Property Manager Page.

Message box is displayed with the values of toggles once Property Manager Page is closed.