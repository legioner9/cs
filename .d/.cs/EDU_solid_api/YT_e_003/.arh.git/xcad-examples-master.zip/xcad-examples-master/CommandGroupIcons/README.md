![Icons rendered in menu, toolbar and command tab box](toolbar-icons.png)

This example demonstrates how .PNG icons of different sizes can be rendered in menu, toolbar and tab box. Transparent pixels are rendered as transparent color in SOLIDWORKS. Image sizes are automatically unified.