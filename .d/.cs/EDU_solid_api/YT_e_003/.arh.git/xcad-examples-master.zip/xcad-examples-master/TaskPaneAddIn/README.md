# WPF TaskPane and MSI-Installers

This example demonstrates how to create Task pane and host WPF control with custom View Model\r\nThis example also contais 2 MSI-installer projects: Windows Installer XML (WiX) and Visual Studio (VSI)