![Toggle button in SOLIDWORKS toolbar](states.png)

Example demonstrates how to add a toggle (check) button into the SOLIDWORKS menu, toolbar and command managar. Click the button to change the state.