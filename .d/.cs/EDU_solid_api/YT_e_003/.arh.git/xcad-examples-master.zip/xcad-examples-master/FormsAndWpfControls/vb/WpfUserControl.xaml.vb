﻿Imports FormsAndWpfControls.My.Resources
Imports Xarial.XCad.Base.Attributes

<Title("WPF Control")>
<Icon(GetType(Resources), NameOf(Resources.wpf_icon))>
Public Class WpfUserControl

End Class
