![Property Manager page and preview of box macro feature](box-macro-feature.png)

This example demonstrates how to create a box element using macro feature.

Macro feature supports

* Previewing
* Editing
* Dimensions