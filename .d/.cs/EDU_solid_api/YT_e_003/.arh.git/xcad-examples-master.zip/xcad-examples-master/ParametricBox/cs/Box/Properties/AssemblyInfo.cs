﻿using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: Guid("8D48325C-C9CC-4574-AE08-BF3B9CC7EC81")]