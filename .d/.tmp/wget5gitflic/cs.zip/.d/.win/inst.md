new console project

    $dotnet new console

powerShell adm

    $ [environment]::osversion
    $ dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
    $ dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart

download  https://github.com/marchaesen/vcxsrv and install
path : \\wsl$

    $ sudo apt-get update
    $ sudo apt install gnome-terminal
    $ sudo apt install nautilus