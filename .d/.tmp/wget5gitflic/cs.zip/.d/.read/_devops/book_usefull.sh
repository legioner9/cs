#!/bin/bash
  
echo "add autoload <php8.2-fpm> :: systemctl enable --now php8.2-fpm"
