#!/bin/bash

_init_boot_() {
    local name=(flic
        hab
    )
    # https://gitflic.ru/project/legioner9/stl/blob/raw?file=.d%2F.arb%2Flib.arb%2F_XXX_stl0.ram%2F.grot%2F_XXX_stl0.hie
    # https://raw.githubusercontent.com/legioner9/stl/refs/heads/master/.d/.arb/lib.arb/_XXX_stl0.ram/.grot/_XXX_stl0.hie
    local res=("https://gitflic.ru/project/legioner9/stl/blob/raw?file="
        "https://raw.githubusercontent.com/legioner9/stl/refs/heads/master/"
    )

    # select 
}
